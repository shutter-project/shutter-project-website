package Gtk2::ImageView::Install::Files;

$self = {
          'inc' => '-DPNG_NO_MMX_CODE -I/usr/include/gtk-2.0 -I/usr/lib/gtk-2.0/include -I/usr/include/atk-1.0 -I/usr/include/cairo -I/usr/include/pango-1.0 -I/usr/include/glib-2.0 -I/usr/lib/glib-2.0/include -I/usr/include/freetype2 -I/usr/include/libpng12 -I/usr/include/pixman-1  ',
          'typemaps' => [
                          'gtkimageviewperl.typemap'
                        ],
          'deps' => [
                      'Glib',
                      'Gtk2',
                      'Cairo'
                    ],
          'libs' => '-lgtkimageview -lgtk-x11-2.0 -lgdk-x11-2.0 -latk-1.0 -lgdk_pixbuf-2.0 -lm -lpangocairo-1.0 -lpango-1.0 -lcairo -lgobject-2.0 -lgmodule-2.0 -ldl -lglib-2.0  '
        };


# this is for backwards compatiblity
@deps = @{ $self->{deps} };
@typemaps = @{ $self->{typemaps} };
$libs = $self->{libs};
$inc = $self->{inc};

	$CORE = undef;
	foreach (@INC) {
		if ( -f $_ . "/Gtk2/ImageView/Install/Files.pm") {
			$CORE = $_ . "/Gtk2/ImageView/Install/";
			last;
		}
	}

1;
