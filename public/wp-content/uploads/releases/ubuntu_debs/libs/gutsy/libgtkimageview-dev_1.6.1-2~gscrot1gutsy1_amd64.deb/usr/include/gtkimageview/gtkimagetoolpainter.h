#ifndef __GTKIMAGETOOLPAINTER_H__
#define __GTKIMAGETOOLPAINTER_H__

#include "gtkiimagetool.h"
#include "gtkimageview.h"
#include "mouse_handler.h"

G_BEGIN_DECLS

#define GTK_TYPE_IMAGE_TOOL_PAINTER            (gtk_image_tool_painter_get_type ())
#define GTK_IMAGE_TOOL_PAINTER(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), GTK_TYPE_IMAGE_TOOL_PAINTER, GtkImageToolPainter))
#define GTK_IMAGE_TOOL_PAINTER_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), GTK_TYPE_IMAGE_TOOL_PAINTER, GtkImageToolPainterClass))
#define GTK_IS_IMAGE_TOOL_PAINTER(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), GTK_TYPE_IMAGE_TOOL_PAINTER))
#define GTK_IS_IMAGE_TOOL_PAINTER_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), GTK_TYPE_IMAGE_TOOL_PAINTER))
#define GTK_IMAGE_TOOL_PAINTER_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), GTK_TYPE_IMAGE_TOOL_PAINTER, GtkImageToolPainterClass))

typedef struct _GtkImageToolPainter GtkImageToolPainter;
typedef struct _GtkImageToolPainterClass GtkImageToolPainterClass;

struct _GtkImageToolPainter
{
    GObject             parent;
    GtkImageView       *view;

    /* Cursor to use */
    GdkCursor          *crosshair;

    /* Cache for the image */
    GdkPixbufDrawCache *cache;

    MouseHandler       *mouse_handler;
};

struct _GtkImageToolPainterClass
{
    GObjectClass parent;
};

GType         gtk_image_tool_painter_get_type     (void);

/* Constructors */
GtkIImageTool *gtk_image_tool_painter_new         (GtkImageView *view);


G_END_DECLS

#endif
