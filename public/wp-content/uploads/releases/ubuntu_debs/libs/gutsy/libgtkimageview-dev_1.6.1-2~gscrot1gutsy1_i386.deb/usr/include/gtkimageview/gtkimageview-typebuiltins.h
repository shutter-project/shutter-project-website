#ifndef __GTKIMAGEVIEW_TYPEBUILTINS_H__
 #define __GTKIMAGEVIEW_TYPEBUILTINS_H__
 G_BEGIN_DECLS

/* Generated data (by glib-mkenums) */

/* enumerations from "gdkpixbufdrawcache.h" */
GType gdk_pixbuf_draw_method_get_type (void) G_GNUC_CONST;
#define GDK_TYPE_PIXBUF_DRAW_METHOD (gdk_pixbuf_draw_method_get_type())

/* Generated data ends here */


/* Generated data (by glib-mkenums) */

/* enumerations from "gtkimagetoolselector.h" */
GType hotspot_type_get_type (void) G_GNUC_CONST;
#define GTK_TYPE_TYPE (hotspot_type_get_type())
/* enumerations from "gtkimageview.h" */
GType gtk_image_transp_get_type (void) G_GNUC_CONST;
#define GTK_TYPE_IMAGE_TRANSP (gtk_image_transp_get_type())

/* Generated data ends here */

G_END_DECLS

 #endif
